﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Newtonsoft.Json;
using System.IO;

namespace JSONDataStorage
{
    class Item : IEquatable<Item>
    {
        public string nome;
        public int preco;

        public Item(string nome, int preco = 0)
        {
            this.nome = nome;
            this.preco = preco;
        }

        public bool Equals(Item other)
        {
            if (other == null) return false;
            return (this.nome.Equals(other.nome));
        }
    }



    class Program
    {
        static void Main(string[] args)
        {
            //Lê o arquivo json e desealiza
            Console.WriteLine("Lendo arquivo data.json");
            string jsonSTRING = File.ReadAllText("data.json");
            List<Item> myList = JsonConvert.DeserializeObject<List<Item>>(jsonSTRING);

            if (myList == null)
                myList = new List<Item>();

            string input = "";
            int inputInt = 0;
            string inputString = "";

            while (input != "q")
            {
                Console.WriteLine("Pressione 'a' para Adicionar novo item");
                Console.WriteLine("Pressione 'd' para Excluir item");
                Console.WriteLine("Pressione 's' para Mostrar itens");
                Console.WriteLine("Pressione 'q' para Sair");
                Console.WriteLine("Selecione o comando:");
                input = Console.ReadLine();
                switch (input)
                {
                    case "a":
                        Console.WriteLine("Cadastro de Novo Item");
                        Console.WriteLine("Digite o nome do item:");
                        inputString = Console.ReadLine();
                        Console.WriteLine("Digite o preço do item:");
                        inputInt = Convert.ToInt32(Console.ReadLine());
                        myList.Add(new Item(inputString, inputInt));
                        Console.WriteLine("Adicionado item " + inputString + " com preço " + inputInt);
                        break;
                    case "d":
                        Console.WriteLine("Cadastro de Novo Item");
                        Console.WriteLine("Digite o nome do item:");
                        inputString = Console.ReadLine();
                        myList.Remove(new Item(inputString));
                        Console.WriteLine("Item " + inputString + " excluído com sucesso.");
                        break;
                    case "q":
                        Console.WriteLine("Sair do Programa.");
                        break;
                    case "s":
                        Console.WriteLine("\nExibir informações:");
                        foreach (Item item in myList)
                        {
                            Console.WriteLine("Item: " + item.nome + " | $" + item.preco);
                        }
                        Console.WriteLine("\n");
                        break;
                    default:
                        Console.WriteLine("Comando inválido, tente novamente");
                        break;
                }

                Console.WriteLine("Editando data.json");
                string data = JsonConvert.SerializeObject(myList);
                File.WriteAllText("data.json", data);
                Console.ReadLine();
            }
        }
    }
}
